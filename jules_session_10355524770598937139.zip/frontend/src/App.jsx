import React, { useState, useEffect } from 'react';
import io from 'socket.io-client';
import Sidebar from './components/Sidebar';
import Header from './components/Header';
import OverallReadiness from './components/OverallReadiness';
import DailyGoal from './components/DailyGoal';
import PerformanceTrends from './components/PerformanceTrends';
import RecommendedInterview from './components/RecommendedInterview';
import SkillsBreakdown from './components/SkillsBreakdown';
import DailyReminders from './components/DailyReminders';
import RecentActivity from './components/RecentActivity';

const socket = io('http://localhost:3001');

function App() {
  const [dashboardData, setDashboardData] = useState(null);

  useEffect(() => {
    fetch('http://localhost:3001/api/dashboard')
      .then((res) => res.json())
      .then((data) => setDashboardData(data));

    socket.on('dashboardUpdate', (data) => {
      setDashboardData((prevData) => ({ ...prevData, ...data }));
    });

    return () => {
      socket.off('dashboardUpdate');
    };
  }, []);

  if (!dashboardData) {
    return <div>Loading...</div>;
  }

  return (
    <div className="bg-[#f8f9fb] dark:bg-background-dark font-display text-slate-900 dark:text-slate-100 min-h-screen flex">
      <Sidebar />
      <main className="flex-1 p-10 overflow-y-auto">
        <Header />
        <div className="grid grid-cols-12 gap-6">
          <div className="col-span-12 lg:col-span-8 space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <OverallReadiness data={dashboardData.overallReadiness} />
              <DailyGoal data={dashboardData.dailyGoal} />
            </div>
            <PerformanceTrends data={dashboardData.performanceTrends} />
            <RecommendedInterview />
          </div>
          <div className="col-span-12 lg:col-span-4 space-y-6">
            <SkillsBreakdown data={dashboardData.skillsBreakdown} />
            <DailyReminders />
            <RecentActivity data={dashboardData.recentActivity} />
          </div>
        </div>
      </main>
    </div>
  );
}

export default App;
