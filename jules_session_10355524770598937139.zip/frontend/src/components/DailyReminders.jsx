import React from 'react';

const DailyReminders = () => {
  return (
    <div className="bg-white dark:bg-slate-900 p-6 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm">
      <h3 className="text-sm font-bold mb-6 flex items-center gap-2">
        <span className="material-symbols-outlined text-slate-400 text-xl">notifications</span>
        Daily Reminders
      </h3>
      <div className="space-y-6">
        <div className="flex items-center justify-between p-3.5 bg-slate-50 dark:bg-slate-800/50 rounded-lg">
          <div className="flex items-center gap-3">
            <div className="size-2 rounded-full bg-green-500"></div>
            <span className="text-xs font-semibold">Email Notifications</span>
          </div>
          <span className="text-[10px] font-black text-green-600 uppercase tracking-tight">Active</span>
        </div>
        <div className="p-4 bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-lg">
          <p className="text-[10px] font-extrabold text-slate-400 uppercase tracking-widest mb-2">
            Next Scheduled Session
          </p>
          <div className="flex items-center gap-2">
            <span className="material-symbols-outlined text-xl text-primary">event</span>
            <span className="text-sm font-bold">Tomorrow, 10:00 AM</span>
          </div>
        </div>
        <div className="flex gap-3">
          <button className="flex-1 bg-slate-50 dark:bg-slate-800 py-3 rounded-lg text-xs font-bold hover:bg-slate-100 transition-colors border border-slate-100 dark:border-slate-700">
            Manage
          </button>
          <button className="flex-1 bg-primary/10 text-primary py-3 rounded-lg text-xs font-bold hover:bg-primary/20 transition-colors">
            Reschedule
          </button>
        </div>
      </div>
    </div>
  );
};

export default DailyReminders;
