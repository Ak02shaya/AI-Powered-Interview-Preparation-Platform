import React from 'react';

const RecommendedInterview = () => {
  return (
    <div className="bg-primary rounded-xl p-8 text-white shadow-xl relative overflow-hidden">
      <div className="relative z-10 flex items-center justify-between">
        <div className="max-w-md">
          <span className="bg-white/20 text-[10px] font-extrabold px-2 py-1 rounded mb-4 inline-block tracking-wider">
            RECOMMENDED FOR YOU
          </span>
          <h3 className="text-2xl font-extrabold mb-3">Ready to level up?</h3>
          <p className="text-blue-100 text-sm leading-relaxed">
            Start a tailored Mock Interview for{' '}
            <span className="font-bold underline cursor-pointer">Senior Product Manager</span> roles and
            get real-time AI feedback.
          </p>
        </div>
        <button className="bg-white text-primary px-8 py-4 rounded-lg font-bold hover:bg-blue-50 transition-colors shadow-lg whitespace-nowrap">
          Start Interview
        </button>
      </div>
      <div className="absolute -right-12 -top-12 w-64 h-64 bg-white/10 rounded-full blur-3xl"></div>
      <div className="absolute -bottom-12 right-24 w-48 h-48 bg-blue-400/20 rounded-full blur-2xl"></div>
    </div>
  );
};

export default RecommendedInterview;
