import React from 'react';

const RecentActivity = ({ data }) => {
  const getIcon = (type) => {
    switch (type) {
      case 'interview':
        return 'check';
      case 'skill':
        return 'history_edu';
      default:
        return '';
    }
  };

  return (
    <div className="bg-white dark:bg-slate-900 p-6 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm">
      <h3 className="text-sm font-bold mb-6">Recent Activity</h3>
      <div className="space-y-8 relative">
        <div className="absolute left-3.5 top-2 bottom-2 w-px bg-slate-100 dark:bg-slate-800"></div>
        {data.map((item, index) => (
          <div className="flex gap-4 relative z-10" key={index}>
            <div className={`size-7 rounded-full ${item.type === 'interview' ? 'bg-primary' : 'bg-slate-200 dark:bg-slate-700'} flex items-center justify-center border-2 border-white dark:border-slate-900 shadow-sm`}>
              <span className={`material-symbols-outlined ${item.type === 'interview' ? 'text-white' : 'text-slate-500'} text-[14px] font-black`}>
                {getIcon(item.type)}
              </span>
            </div>
            <div>
              <p className="text-xs font-bold">{item.title}</p>
              <p className="text-[10px] text-slate-400 mt-1">{item.detail}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default RecentActivity;
