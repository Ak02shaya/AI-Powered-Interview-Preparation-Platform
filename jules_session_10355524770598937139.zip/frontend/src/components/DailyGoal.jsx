import React from 'react';

const DailyGoal = ({ data }) => {
  const progress = (data.completed / data.total) * 100;
  return (
    <div className="bg-white dark:bg-slate-900 p-6 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm">
      <div className="flex justify-between items-center mb-4">
        <p className="text-slate-500 dark:text-slate-400 text-sm font-medium">Daily Goal</p>
        <p className="text-sm font-bold text-primary">{data.completed}/{data.total}</p>
      </div>
      <div className="relative h-2 bg-slate-100 dark:bg-slate-800 rounded-full mb-6">
        <div className="absolute h-full bg-primary rounded-full" style={{ width: `${progress}%` }}></div>
      </div>
      <p className="text-sm text-slate-600 dark:text-slate-400 leading-relaxed">
        Complete {data.total - data.completed} more mock interview to reach your daily target.
      </p>
      <div className="mt-6 flex items-center gap-2 text-xs font-medium text-slate-400">
        <span className="material-symbols-outlined text-sm">schedule</span>
        Avg. session time: 15 mins
      </div>
    </div>
  );
};

export default DailyGoal;
