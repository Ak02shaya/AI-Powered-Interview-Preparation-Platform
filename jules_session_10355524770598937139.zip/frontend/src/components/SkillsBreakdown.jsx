import React from 'react';

const SkillsBreakdown = ({ data }) => {
  return (
    <div className="bg-white dark:bg-slate-900 p-6 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm">
      <h3 className="text-sm font-bold mb-8 flex items-center gap-2">
        <span className="material-symbols-outlined text-primary text-xl">analytics</span>
        Skills Breakdown
      </h3>
      <div className="space-y-6">
        <div className="space-y-2">
          <div className="flex justify-between text-xs font-semibold">
            <span>Aptitude</span>
            <span className="text-slate-400">{data.aptitude}%</span>
          </div>
          <div className="h-2 bg-slate-100 dark:bg-slate-800 rounded-full">
            <div className="h-full bg-blue-500 rounded-full" style={{ width: `${data.aptitude}%` }}></div>
          </div>
        </div>
        <div className="space-y-2">
          <div className="flex justify-between text-xs font-semibold">
            <span>Speaking</span>
            <span className="text-slate-400">{data.speaking}%</span>
          </div>
          <div className="h-2 bg-slate-100 dark:bg-slate-800 rounded-full">
            <div className="h-full bg-indigo-500 rounded-full" style={{ width: `${data.speaking}%` }}></div>
          </div>
        </div>
        <div className="space-y-2">
          <div className="flex justify-between text-xs font-semibold">
            <span>Listening</span>
            <span className="text-slate-400">{data.listening}%</span>
          </div>
          <div className="h-2 bg-slate-100 dark:bg-slate-800 rounded-full">
            <div className="h-full bg-cyan-500 rounded-full" style={{ width: `${data.listening}%` }}></div>
          </div>
        </div>
        <div className="space-y-2">
          <div className="flex justify-between text-xs font-semibold">
            <span>Reading</span>
            <span className="text-slate-400">{data.reading}%</span>
          </div>
          <div className="h-2 bg-slate-100 dark:bg-slate-800 rounded-full">
            <div className="h-full bg-sky-500 rounded-full" style={{ width: `${data.reading}%` }}></div>
          </div>
        </div>
      </div>
      <button className="w-full mt-10 text-xs font-bold text-primary hover:underline">
        View Detailed Analytics
      </button>
    </div>
  );
};

export default SkillsBreakdown;
