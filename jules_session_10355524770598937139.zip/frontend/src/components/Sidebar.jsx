import React from 'react';

const Sidebar = () => {
  return (
    <aside className="w-64 border-r border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 flex flex-col h-screen sticky top-0">
      <div className="p-6 flex flex-col h-full">
        <div className="flex items-center gap-3 mb-8">
          <div className="bg-primary rounded-lg p-2 text-white flex items-center justify-center">
            <span className="material-symbols-outlined">bolt</span>
          </div>
          <h2 className="text-xl font-extrabold tracking-tight">GetReadyAi</h2>
        </div>
        <div className="flex items-center gap-3 p-3 mb-8 bg-slate-50 dark:bg-slate-800 rounded-xl">
          <div
            className="bg-center bg-no-repeat aspect-square bg-cover rounded-full size-10"
            style={{
              backgroundImage:
                'url("https://lh3.googleusercontent.com/aida-public/AB6AXuDncb98cFnjTUG0_qZX9xj9aF7aaU2Kx4LnvpsHmCPt6nmhlTBNgkRstaP139-LTgs91QHlv4k6RJ6VO99FS4-hP1h5vPaxWIxEHL9l6zH6npd484TbP7ntUBQdpztKzZysRogUbaxCyGWEUlaEJpVuFNcF0BehGAq0HtN_T6tJqeXjDx9nbI8Kp0CqQ9ZVfFLtoGX2mAMLIb5Oqpa4vZSjt3yqQLaoxLVcGKbIkjmR4uIFWfFq-28xFW-Q5Yh_r-5mvz4V2DbQBXZe")',
            }}
          ></div>
          <div className="flex flex-col overflow-hidden">
            <h1 className="text-sm font-semibold truncate">Alex Johnson</h1>
            <p className="text-slate-500 dark:text-slate-400 text-xs">Premium Member</p>
          </div>
        </div>
        <nav className="flex flex-col gap-1 grow">
          <a className="flex items-center gap-3 px-3 py-2.5 rounded-lg active-nav" href="#">
            <span className="material-symbols-outlined text-[22px]">home</span>
            <span className="text-sm font-semibold">Home</span>
          </a>
          <a
            className="flex items-center gap-3 px-3 py-2.5 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            href="#"
          >
            <span className="material-symbols-outlined text-[22px]">forum</span>
            <span className="text-sm font-semibold">Mock Interviews</span>
          </a>
          <a
            className="flex items-center gap-3 px-3 py-2.5 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            href="#"
          >
            <span className="material-symbols-outlined text-[22px]">menu_book</span>
            <span className="text-sm font-semibold">Skill Library</span>
          </a>
          <a
            className="flex items-center gap-3 px-3 py-2.5 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            href="#"
          >
            <span className="material-symbols-outlined text-[22px]">history</span>
            <span className="text-sm font-semibold">History</span>
          </a>
          <a
            className="flex items-center gap-3 px-3 py-2.5 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            href="#"
          >
            <span className="material-symbols-outlined text-[22px]">settings</span>
            <span className="text-sm font-semibold">Settings</span>
          </a>
        </nav>
        <div className="mt-auto">
          <button className="w-full bg-primary hover:bg-blue-700 text-white rounded-lg py-2.5 text-sm font-bold flex items-center justify-center gap-2 transition-all">
            <span className="material-symbols-outlined text-sm">rocket_launch</span>
            Upgrade to Pro
          </button>
        </div>
      </div>
    </aside>
  );
};

export default Sidebar;
