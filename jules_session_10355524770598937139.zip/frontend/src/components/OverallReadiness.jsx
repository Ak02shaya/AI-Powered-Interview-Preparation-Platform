import React from 'react';

const OverallReadiness = ({ data }) => {
  return (
    <div className="bg-white dark:bg-slate-900 p-6 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm">
      <div className="flex justify-between items-start mb-4">
        <div>
          <p className="text-slate-500 dark:text-slate-400 text-sm font-medium">Overall Readiness</p>
          <h3 className="text-4xl font-extrabold mt-1">{data.score}%</h3>
        </div>
        <span className="bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400 px-2 py-1 rounded-lg text-xs font-bold flex items-center gap-1">
          <span className="material-symbols-outlined text-xs">trending_up</span> +{data.change}%
        </span>
      </div>
      <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed mb-6">
        Interview Ready status achieved. Your performance in Speaking improved significantly.
      </p>
      <div className="w-full bg-slate-100 dark:bg-slate-800 h-1.5 rounded-full overflow-hidden">
        <div className="h-full bg-primary" style={{ width: `${data.score}%` }}></div>
      </div>
    </div>
  );
};

export default OverallReadiness;
