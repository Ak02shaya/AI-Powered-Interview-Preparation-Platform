import React from 'react';

const Header = () => {
  return (
    <header className="flex justify-between items-start mb-10">
      <div>
        <h1 className="text-4xl font-extrabold tracking-tight text-slate-900 dark:text-white">
          Good morning, Alex.
        </h1>
        <p className="text-slate-500 dark:text-slate-400 mt-2 text-lg">
          You're 15% closer to your goal today. Keep the momentum going!
        </p>
      </div>
      <div className="flex items-center gap-3">
        <button className="px-5 py-2.5 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-sm font-bold flex items-center gap-2 shadow-sm">
          <span className="material-symbols-outlined text-lg">person</span>
          View Profile
        </button>
      </div>
    </header>
  );
};

export default Header;
