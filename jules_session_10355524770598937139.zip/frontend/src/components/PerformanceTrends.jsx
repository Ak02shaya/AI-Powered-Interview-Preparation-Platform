import React from 'react';

const PerformanceTrends = ({ data }) => {
  const MOCK_DATA = "M0 109C18.1538 109 18.1538 21 36.3077 21C54.4615 21 54.4615 41 72.6154 41C90.7692 41 90.7692 93 108.923 93C127.077 93 127.077 33 145.231 33C163.385 33 163.385 101 181.538 101C199.692 101 199.692 61 217.846 61C236 61 236 45 254.154 45C272.308 45 272.308 121 290.462 121C308.615 121 308.615 149 326.769 149C344.923 149 344.923 1 363.077 1C381.231 1 381.231 81 399.385 81C417.538 81 417.538 129 435.692 129C453.846 129 453.846 25 472 25"
  return (
    <div className="bg-white dark:bg-slate-900 p-6 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h3 className="text-lg font-bold">Performance Trends</h3>
          <div className="flex gap-2 items-center mt-1">
            <span className="text-2xl font-extrabold text-slate-900 dark:text-white">{data.average}</span>
            <span className="text-green-600 dark:text-green-400 text-sm font-bold flex items-center">
              <span className="material-symbols-outlined text-sm">north</span> {data.change}%
            </span>
          </div>
        </div>
        <select className="bg-slate-50 dark:bg-slate-800 border border-slate-100 dark:border-slate-700 rounded-lg text-xs font-bold py-1.5 px-3">
          <option>Last 7 Days</option>
          <option>Last 30 Days</option>
        </select>
      </div>
      <div className="h-[250px] w-full">
        <svg
          fill="none"
          height="100%"
          preserveAspectRatio="none"
          viewBox="0 0 478 150"
          width="100%"
          xmlns="http://www.w3.org/2000/svg"
        >
          <path
            d={MOCK_DATA}
            stroke="#195de6"
            strokeLinecap="round"
            strokeWidth="3"
          ></path>
        </svg>
        <div className="flex justify-between px-2 mt-6 text-[10px] font-bold text-slate-400 uppercase tracking-widest">
          <span>Mon</span>
          <span>Tue</span>
          <span>Wed</span>
          <span>Thu</span>
          <span>Fri</span>
          <span>Sat</span>
          <span>Sun</span>
        </div>
      </div>
    </div>
  );
};

export default PerformanceTrends;
